Three files are contained in this zip file:
1)	hixdata.dta is a Stata-format data file containing the base data used in Lewbel and Pendakur "Tricks with Hicks: The EASI Demand System".
2)	'iterated 3sls with pz,py,zy.do' contains stata code to estimate the EASI model via iterated 3 stage least squares (this is the model we estimate in the paper);
3)	'iterated 3sls without pz,py,zy.do' contains stata code to estimate the EASI model without interaction terms.
